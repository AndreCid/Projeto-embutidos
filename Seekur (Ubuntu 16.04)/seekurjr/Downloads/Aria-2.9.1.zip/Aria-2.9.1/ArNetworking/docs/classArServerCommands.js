var classArServerCommands =
[
    [ "ServerCommands", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4", [
      [ "SHUTDOWN", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4ac8bd4e692eabfb24d487705728b0fb6e", null ],
      [ "INTRODUCTION", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4af0d0401b61666b52feac6d5851263733", null ],
      [ "UDP_INTRODUCTION", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4a6d63f5cecb9f92808a62954496bfe279", null ],
      [ "UDP_CONFIRMATION", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4a346278536dfe0300374f5fbaba1d6ff2", null ],
      [ "CONNECTED", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4acab3bf86441a65c24cc045e8b0192ce2", null ],
      [ "REJECTED", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4adee1cad7b02f1ea54bb37b17213f1a75", null ],
      [ "TCP_ONLY", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4afbeb928f4be2b6d4b1d4d34311e12ae7", null ],
      [ "LIST", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4a141500872f293f3a2e7763562b728301", null ],
      [ "LISTSINGLE", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4aa22a779d0c5e4aba20a6273dc24c3fe4", null ],
      [ "LISTARGRET", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4af789d41c3ea7728e740a6a10a46b882d", null ],
      [ "LISTARGRETSINGLE", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4a00142b7d8bbdb4d4264d6e4c85135b00", null ],
      [ "LISTGROUPANDFLAGS", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4a46ba97bce7f0fd78036ea0395fd75b49", null ],
      [ "LISTGROUPANDFLAGSSINGLE", "classArServerCommands.html#a4b1d453536c145108110dd2e1eee89c4acff7f30183e09b5722f66f20390c6fe1", null ]
    ] ],
    [ "Type", "classArServerCommands.html#a17e8a1248f23b0f1dde4606af34b0efd", [
      [ "TYPE_UNSPECIFIED", "classArServerCommands.html#a17e8a1248f23b0f1dde4606af34b0efdaebd1dc6f46009b607589b0ea2cea27c5", null ],
      [ "TYPE_REAL", "classArServerCommands.html#a17e8a1248f23b0f1dde4606af34b0efda04341eabfc9c8b186c83fe279bd30fe0", null ],
      [ "TYPE_SIMULATED", "classArServerCommands.html#a17e8a1248f23b0f1dde4606af34b0efda04379d0d398a69a22056e190fbb6be2a", null ],
      [ "TYPE_NONE", "classArServerCommands.html#a17e8a1248f23b0f1dde4606af34b0efdaaaecfa9e450c08cc965e23798c977deb", null ]
    ] ],
    [ "toString", "classArServerCommands.html#af5713e054859cdb761f75e1113ea3ee2", null ]
];