var classArServerClientData =
[
    [ "ArServerClientData", "classArServerClientData.html#a0dadbada5fa1cc0d8d3b0b9d8e31c37c", null ],
    [ "~ArServerClientData", "classArServerClientData.html#ad7d214ecdc3aafc38e5105e3703b4157", null ],
    [ "getLastSent", "classArServerClientData.html#a3327a7dac7f6bc8ebc43b76e3e6b9331", null ],
    [ "getMSec", "classArServerClientData.html#a36086e3cb18655b178aa1d46d158a8f9", null ],
    [ "getPacket", "classArServerClientData.html#a4f15b2c7ef32087bb1956ce91d724dab", null ],
    [ "getServerData", "classArServerClientData.html#a55915b53e5ca0b79c4eb53d4aace3426", null ],
    [ "setLastSentToNow", "classArServerClientData.html#a41a9324acec7e484b3282368e00251e7", null ],
    [ "setMSec", "classArServerClientData.html#a77d6e5734caad7707a42ebb6304c5818", null ],
    [ "setPacket", "classArServerClientData.html#a7ff73c5e58fa960b900838230f0d5f16", null ],
    [ "myLastSent", "classArServerClientData.html#afb558e8494fb2a7e6c4c60d213492813", null ],
    [ "myMSecInterval", "classArServerClientData.html#adcb566b629e7184a3eeca14326cf7e6b", null ],
    [ "myPacket", "classArServerClientData.html#ae535ef21b0e001bb6fc27d5a95913392", null ],
    [ "myReadLength", "classArServerClientData.html#adc724533a70aab2c0676682fbbd81f8a", null ],
    [ "myServerData", "classArServerClientData.html#a37b44db9cd0b5d2311a77c95e7a1189a", null ]
];