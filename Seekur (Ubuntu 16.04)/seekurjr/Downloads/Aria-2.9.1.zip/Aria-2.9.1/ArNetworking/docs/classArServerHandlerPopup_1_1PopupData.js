var classArServerHandlerPopup_1_1PopupData =
[
    [ "PopupData", "classArServerHandlerPopup_1_1PopupData.html#aed5a2d8c3fdc65a8a9d091a7eaab6f8a", null ],
    [ "~PopupData", "classArServerHandlerPopup_1_1PopupData.html#ad44bf197df47820294e17b9d332f01de", null ],
    [ "myCallback", "classArServerHandlerPopup_1_1PopupData.html#a505723a68c4627c997ba381f9104cb17", null ],
    [ "myID", "classArServerHandlerPopup_1_1PopupData.html#a1b6bf5e55c74d6a492efca6e36a48fc4", null ],
    [ "myPopupInfo", "classArServerHandlerPopup_1_1PopupData.html#a5fd8ff43b3e1cce71ece78b26e2842d0", null ],
    [ "myStarted", "classArServerHandlerPopup_1_1PopupData.html#a04a55773508583fc62ad93b532494fc7", null ]
];