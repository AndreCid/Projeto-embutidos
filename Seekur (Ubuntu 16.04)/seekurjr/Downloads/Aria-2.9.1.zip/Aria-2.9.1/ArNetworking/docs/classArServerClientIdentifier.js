var classArServerClientIdentifier =
[
    [ "ArServerClientIdentifier", "classArServerClientIdentifier.html#aea6fbe3f62686f834dbef12f1968c61d", null ],
    [ "~ArServerClientIdentifier", "classArServerClientIdentifier.html#a9e085ac397671caa94557a8ca640a3a3", null ],
    [ "getConnectionID", "classArServerClientIdentifier.html#a547cee529202fe508768f04f49559500", null ],
    [ "getHereGoal", "classArServerClientIdentifier.html#a3a2c604fe2545220575e61696bfedc7a", null ],
    [ "getIDString", "classArServerClientIdentifier.html#ae0899fdbba705e8f25fdb0578c0b8c13", null ],
    [ "getSelfIdentifier", "classArServerClientIdentifier.html#a41569d0fbb0c97b3dec239cab7a52070", null ],
    [ "matches", "classArServerClientIdentifier.html#ac18520127ed3fc33885b1e94da5b05d2", null ],
    [ "rebuildIDString", "classArServerClientIdentifier.html#a67ec0f1beb51d66fdd55d3484008c2f1", null ],
    [ "setConnectionID", "classArServerClientIdentifier.html#a4a6950f2c40d5583e56ac729100aec95", null ],
    [ "setHereGoal", "classArServerClientIdentifier.html#a3c89948e9a7039ff6520c0ea31338c77", null ],
    [ "setSelfIdentifier", "classArServerClientIdentifier.html#a6ebf449e7d4fb839c812f749fc923f45", null ],
    [ "myConnectionID", "classArServerClientIdentifier.html#aa8e81b9380c5bc1e10e89dbd85c3af3e", null ],
    [ "myHereGoal", "classArServerClientIdentifier.html#af7441c42d8850cc224f498b50955b2b0", null ],
    [ "myIDString", "classArServerClientIdentifier.html#afd379718ef2d464d3a7f0d914aefe061", null ],
    [ "mySelfIdentifier", "classArServerClientIdentifier.html#aaaebd5e4e054f911b65992bbfe5f860a", null ]
];