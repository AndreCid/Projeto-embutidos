var classArServerSimplePopup =
[
    [ "ArServerSimplePopup", "classArServerSimplePopup.html#a20550a4670adfe8ec55dd8ad01697a74", null ],
    [ "~ArServerSimplePopup", "classArServerSimplePopup.html#a4c0975b7f6174b4deef90f26e2e09831", null ],
    [ "simplePopup", "classArServerSimplePopup.html#a3a494ab35569800075a26df398ed2936", null ],
    [ "myCommands", "classArServerSimplePopup.html#abad77dee64c324931532ffceb5c684b7", null ],
    [ "myPopupHandler", "classArServerSimplePopup.html#a134647698053f7948eedce5f9a2b7be0", null ],
    [ "mySimplePopupCB", "classArServerSimplePopup.html#a36d2ce97961f0f091838d5fb2a58f8ba", null ]
];