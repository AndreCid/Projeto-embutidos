var classPtzCameraExample =
[
    [ "PtzCameraExample", "classPtzCameraExample.html#af217e9aaaddce8f100b2b5628e715e11", null ],
    [ "init", "classPtzCameraExample.html#a0fe9f62f695168f6e67eedfdfbfa76f9", null ],
    [ "run", "classPtzCameraExample.html#abebd051cf8fc085f1d3d7b505e1a8c67", null ]
];